const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const session = require('express-session');
const axios = require('axios');

const app = express();
const PORT = 3000;

// MySQL database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Replace with your MySQL username
    password: 'Hudarock123&', // Replace with your MySQL password
    database: 'ZeroDayHunter_db'
});

db.connect(err => {
    if (err) throw err;
    console.log('Connected to ZeroDayHunter_db');
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.json()); // Parse JSON bodies
app.use(session({
    secret: 'mySecret',
    resave: false,
    saveUninitialized: true,
}));

app.get('/', (req, res) => {
    res.send('Welcome to ZeroDayHunter API');
});

// Register endpoint
app.post('/signup', (req, res) => {
    const { username, password } = req.body;

    // Check if username and password are provided
    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required.' });
    }

    // Hash the password before saving it to the database
    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) {
            console.error('Error hashing password:', err);
            return res.status(500).json({ message: 'Error processing request.' });
        }

        // SQL query to insert new user without role
        const query = 'INSERT INTO Users (username, password) VALUES (?, ?)';
        db.query(query, [username, hashedPassword], (err, results) => {
            if (err) {
                console.error('Failed to insert user:', err);
                return res.status(500).json({ message: 'Database error.' });
            }
            res.status(201).json({ message: 'User registered successfully!' });
        });
    });
});

// Login endpoint with session handling and bcrypt password comparison
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const query = 'SELECT * FROM Users WHERE username = ?';
    db.execute(query, [username], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Database error' });
        }

        if (results.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid credentials' });
        }

        const user = results[0];

        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Error comparing passwords' });
            }

            if (!isMatch) {
                return res.status(401).json({ success: false, message: 'Invalid credentials' });
            }

            req.session.user = user;
            return res.status(200).json({ success: true, message: 'Login successful' });
        });
    });
});

// Check session status
app.get('/check-session', (req, res) => {
    if (req.session.user) {
        res.json({ loggedIn: true, user: req.session.user });
    } else {
        res.json({ loggedIn: false });
    }
});

// Scan initiation endpoint (example of adding to Scan_Results)
app.post('/scan', (req, res) => {
    const { project_id, vuln_id } = req.body;

    if (!req.session.user) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    db.query(
        'INSERT INTO Scan_Results (project_id, vuln_id) VALUES (?, ?)',
        [project_id, vuln_id],
        (err, result) => {
            if (err) return res.status(500).json({ error: 'Database error' });
            res.json({ message: 'Scan started', scanId: result.insertId });
        }
    );
});

// ZAP Scan Integration
const ZAP_BASE_URL = "http://localhost:8080"; // Change port if necessary
const ZAP_API_KEY = "gedtc9sqvf59tp1df408o8e72h"; // Replace with your actual API key if required

async function runVulnerabilityScan(targetUrl) {
    try {
        const scanStartResponse = await axios.get(`${ZAP_BASE_URL}/JSON/ascan/action/scan/`, {
            params: {
                url: targetUrl,
                recurse: true,
                apikey: ZAP_API_KEY,
            },
        });

        const scanId = scanStartResponse.data.scan;

        let progress = 0;
        while (progress < 100) {
            const progressResponse = await axios.get(`${ZAP_BASE_URL}/JSON/ascan/view/status/`, {
                params: {
                    scanId: scanId,
                    apikey: ZAP_API_KEY,
                },
            });
            progress = parseInt(progressResponse.data.status, 10);
            console.log(`Scan progress: ${progress}%`);
            await new Promise((resolve) => setTimeout(resolve, 5000));
        }

        const resultsResponse = await axios.get(`${ZAP_BASE_URL}/JSON/core/view/alerts/`, {
            params: {
                baseurl: targetUrl,
                apikey: ZAP_API_KEY,
            },
        });

        return {
            url: targetUrl,
            vulnerabilities: resultsResponse.data.alerts || ["No vulnerabilities detected"],
        };
    } catch (error) {
        console.error("Error during ZAP scan:", error.message);
        return { error: "Failed to perform ZAP scan." };
    }
}

// Endpoint to trigger the ZAP scan
app.post('/zap-scan', async (req, res) => {
    const { url } = req.body;

    if (!url) {
        return res.status(400).json({ error: "URL is required." });
    }

    try {
        const scanResult = await runVulnerabilityScan(url);
        res.json(scanResult);
    } catch (error) {
        console.error("Scan error:", error);
        res.status(500).json({ error: "Failed to perform scan" });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

