async function startScan() {
    // Get the URL from the input field
    const url = document.getElementById("url-input").value;
    
    // Check if the URL is provided
    if (!url) {
        alert("Please enter a URL to scan.");
        return;
    }

    // Update results section to show scanning message
    const resultsContainer = document.getElementById("results-container");
    resultsContainer.innerHTML = "<p>Scanning, please wait...</p>";

    try {
        // Make a POST request to the /scan endpoint
        const response = await fetch("/scan", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ url: url })
        });
        
        // Parse the response as JSON
        const result = await response.json();

        // Display the scan results
        if (result.vulnerabilities) {
            resultsContainer.innerHTML = `
                <h3>Vulnerabilities Found:</h3>
                <ul>
                    ${result.vulnerabilities.map(vuln => `<li>${vuln}</li>`).join('')}
                </ul>
            `;
        } else if (result.error) {
            resultsContainer.innerHTML = `<p>Error: ${result.error}</p>`;
        }
    } catch (error) {
        console.error("Error scanning URL:", error);
        resultsContainer.innerHTML = `<p>Failed to perform scan. Please try again later.</p>`;
    }
}
